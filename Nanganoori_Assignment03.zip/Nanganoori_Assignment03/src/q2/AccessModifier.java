package q2;

public class AccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
