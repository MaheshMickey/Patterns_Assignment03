package q4overrideStaticAndPrivate;

public class Child extends Parent {
	/**
	 * Using private 
	 */
	void displayName() {
		System.out.println("Child Class");
	}
	
	/**
	 * Using static
	 */
	
//	void display() {
//		System.out.println("Static Child Class");
//	}
}
