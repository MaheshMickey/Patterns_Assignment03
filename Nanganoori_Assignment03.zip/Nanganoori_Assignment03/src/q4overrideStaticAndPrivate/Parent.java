package q4overrideStaticAndPrivate;

public class Parent {
	/**
	 * Using Private 
	 */
	private void displayName() {
		System.out.println("ParentClass");
	}
	
	/**
	 * Using Static
	 */
	
	static void display() {
		System.out.println("Static Parent Class");
	}

}

