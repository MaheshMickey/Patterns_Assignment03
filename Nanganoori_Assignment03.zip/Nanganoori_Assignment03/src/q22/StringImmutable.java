package q22;

public class StringImmutable {
	   /**
	     * @param args
	     */
	    public static void main(String[] args) {
	        // TODO Auto-generated method stub
	        String s1 = "java";
	        s1.concat(" rules");
	        System.out.println("s1 refers to " + s1);
	    }



	}